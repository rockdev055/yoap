// favicons entry point
