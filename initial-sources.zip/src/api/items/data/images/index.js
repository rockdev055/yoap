import first from './first'
import second from './second'
import third from './third'
import fourth from './fourth'
import fifth from './fifth'

// TODO: preview & full version of images in gallery

export default [
  first, second, third,
  fourth, fifth
]
