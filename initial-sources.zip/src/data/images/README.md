# Images

This "Images" folder is designated for all image files (jpg, jpeg, png, gif, svg).
During development and production builds, images will be compressed using [imagemin](https://github.com/imagemin/imagemin).
