# Icons

This "Icons" folder is designated for icons (jpg, jpeg, png, gif, svg).
